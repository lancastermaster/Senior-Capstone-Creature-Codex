﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapstoneUIMockUp
{
    public partial class FormResetCodex : Form
    {
        public FormResetCodex()
        {
            InitializeComponent();
            FormResetCodex rc = this;
        }

        private void buttonConfirm_Click(object sender, EventArgs e)
        {
            if (radioButtonNo.Checked)
            {
                this.Hide();
                FormStartScreen.instance.Show();
                this.Dispose();
            }
            if (radioButtonYes.Checked)
            {
                //FormDatabaseReseting fdr = new FormDatabaseReseting();
                //fdr.Show();

                Helper.resetFile();
                Helper.LoadCreatures();
                Helper.populateCreatureList(Data.creatureList);

                Data.creatures = Data.creatureList;

                Application.Restart();

                //FormStartScreen.instance.Show();
                //this.Dispose();
            }
        }
    }
}
