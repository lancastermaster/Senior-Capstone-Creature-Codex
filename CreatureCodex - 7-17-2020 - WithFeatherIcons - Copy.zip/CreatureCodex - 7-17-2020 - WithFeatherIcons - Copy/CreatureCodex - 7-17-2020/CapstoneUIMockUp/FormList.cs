﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapstoneUIMockUp
{
    public partial class FormList : Form
    {
        public FormList fl;
        public FormCreatureEntry cpm = new FormCreatureEntry();
        public FormList()
        {
            InitializeComponent();
            fl = this;
        }

        private void buttonBackMain_Click(object sender, EventArgs e)
        {
            FormStartScreen.instance.Show();
            fl.Dispose();
        }

        private void buttonJump_Click(object sender, EventArgs e)
        {
            foreach (Creature creature in Data.creatures)
            {
                if (creature.Name == fl.listBoxResults.SelectedItem.ToString())
                {
                    cpm.FillPage(creature.HI);
                    cpm.Show();
                    fl.Dispose();
                }
                else
                {

                }
            }
        }
    }
}