﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CapstoneUIMockUp
{
    class Data
    {
        public static List<Creature> creatures = new List<Creature> { };
        public static List<Creature> creatureList = new List<Creature> { };
        public static List<Creature> creatureMythos = new List<Creature> { };
        public static List<Creature> creatureTypes = new List<Creature> { };
        public static List<string> cString = new List<string> { };
        public static List<string> creatureMythoses = new List<string> { };
        
        public static void AddData(string l)
        {
            cString.Add(l);
        }

        
        public static void INILoad()
        {
            string[] data = File.ReadAllLines("Beastcodex.ini");
            foreach (string line in data)
            {
                string l = line.Replace(" ", "");
                string[] parts = l.Split('=');
                if (parts[0].ToLower() == "creaturedatabase")
                {
                    Helper.CreatureDatabase = parts[1];
                }
                if (parts[0].ToLower() == "backupcreaturedatabase")
                {
                    Helper.backupCreatureDatabase = parts[1];
                }
            }
        }
    }
}
