﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Drawing;

namespace CapstoneUIMockUp
{
    public partial class FormCreateNewCreature : Form
    {
        public string fileName;
        public string fileContent;
        public static FormCreateNewCreature instance;
        

        public FormCreateNewCreature()
        {
            InitializeComponent();
            instance = this;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
            FormStartScreen.instance.Show();
        }

        private void buttonSaveEntry_Click(object sender, EventArgs e)
        {
            Creature newCreature = new Creature();

            newCreature.HI = Data.creatures.Count;
            newCreature.Name = textBoxName.Text;
            newCreature.Mythology = textBoxMythos.Text;
            newCreature.Type = textBoxType.Text;
            newCreature.Description = richTextBoxDesc.Text;
            newCreature.Photo = fileName;

            Data.creatures.Add(newCreature);
            Data.AddData(newCreature.HI.ToString() + "^" + newCreature.Name + "^" + newCreature.Mythology + "^" + newCreature.Type + "^" + newCreature.Description + "^" + newCreature.Photo);
            
            
            Helper.clearFileForReset();
            Helper.saveBeasts(Data.cString);

            this.Hide();
            FormStartScreen.instance.Show();
            this.Dispose();
        }

        public void openFile()
        {
            //openFileDialog1.Filter = "Text Files| *.txt";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                //FormCreaturePageMockup.cpm.pictureBoxPhoto.Image = FormCreaturePageMockup.cpm.creaturePhoto;
                //fileName = openFileDialog1.FileName;
                fileName = openFileDialog1.SafeFileName;
                instance.labelImage.Text = fileName;
            }
        }

        private void buttonBrowseFiles_Click(object sender, EventArgs e)
        {
            openFile();
        }
    }
}
