﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace CapstoneUIMockUp
{
    public partial class FormStartScreen : Form
    {
        public static FormStartScreen instance;

        public FormStartScreen()
        {
            InitializeComponent();
            instance = this;
            Helper.LoadCreatures();
            Helper.populateCreatureList();
        }
        
        private void buttonSearchCodex_Click(object sender, EventArgs e)
        {
            FormSearchCodex sc = new FormSearchCodex();
            sc.Show();
            this.Hide();
        }        

        private void buttonCreateNewEntry_Click(object sender, EventArgs e)
        {
            FormCreateNewCreature cnc = new FormCreateNewCreature();
            cnc.Show();
            this.Hide();
        }

        private void buttonReadCodex_Click(object sender, EventArgs e)
        {
            FormCreatureEntry cpm = new FormCreatureEntry();
            cpm.HI = 0;
            cpm.FillPage(cpm.HI);
            cpm.Show();
            this.Hide();
        }

        private void buttonResetCreatureCodex_Click(object sender, EventArgs e)
        {
            FormResetCodex rc = new FormResetCodex();
            rc.Show();
            this.Hide();
        }

        private void buttonExitCodex_Click_1(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void buttonJumpCodex_Click_1(object sender, EventArgs e)
        {
            FormJumpToCreature jtc = new FormJumpToCreature();
            jtc.Show();
            this.Hide();
        }
    }
}
