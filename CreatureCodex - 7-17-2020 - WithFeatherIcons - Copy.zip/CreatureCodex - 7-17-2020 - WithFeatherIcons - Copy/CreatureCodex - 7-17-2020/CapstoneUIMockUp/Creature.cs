﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapstoneUIMockUp
{
    class Creature
    {
        public int HI;
        public string Name, Mythology, Type, Description, Photo;

        /*public void creature(int HI_, string Name_, string Mythology_, string Type_, string Description_, string Photo_)
        {
            HI = HI_;
            Name = Name_;
            Mythology = Mythology_;
            Type = Type_;
            Description = Description_;
            Photo = Photo_;
        }*/
    }
}
