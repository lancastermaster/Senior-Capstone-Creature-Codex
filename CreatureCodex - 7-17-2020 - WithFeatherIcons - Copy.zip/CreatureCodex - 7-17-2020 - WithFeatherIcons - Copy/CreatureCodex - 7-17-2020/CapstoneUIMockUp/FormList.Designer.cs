﻿namespace CapstoneUIMockUp
{
    partial class FormList
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormList));
            this.listBoxResults = new System.Windows.Forms.ListBox();
            this.buttonJump = new System.Windows.Forms.Button();
            this.buttonBackMain = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // listBoxResults
            // 
            this.listBoxResults.FormattingEnabled = true;
            this.listBoxResults.Location = new System.Drawing.Point(12, 18);
            this.listBoxResults.Name = "listBoxResults";
            this.listBoxResults.Size = new System.Drawing.Size(294, 368);
            this.listBoxResults.TabIndex = 0;
            // 
            // buttonJump
            // 
            this.buttonJump.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonJump.BackgroundImage")));
            this.buttonJump.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonJump.Location = new System.Drawing.Point(199, 398);
            this.buttonJump.Name = "buttonJump";
            this.buttonJump.Size = new System.Drawing.Size(49, 40);
            this.buttonJump.TabIndex = 1;
            this.buttonJump.UseVisualStyleBackColor = true;
            this.buttonJump.Click += new System.EventHandler(this.buttonJump_Click);
            // 
            // buttonBackMain
            // 
            this.buttonBackMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonBackMain.BackgroundImage")));
            this.buttonBackMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonBackMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonBackMain.Location = new System.Drawing.Point(12, 398);
            this.buttonBackMain.Name = "buttonBackMain";
            this.buttonBackMain.Size = new System.Drawing.Size(42, 40);
            this.buttonBackMain.TabIndex = 3;
            this.buttonBackMain.UseVisualStyleBackColor = true;
            this.buttonBackMain.Click += new System.EventHandler(this.buttonBackMain_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(60, 412);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Home";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(259, 399);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(47, 26);
            this.label2.TabIndex = 5;
            this.label2.Text = "Jump \r\nTo Entry";
            // 
            // FormList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(318, 450);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonBackMain);
            this.Controls.Add(this.buttonJump);
            this.Controls.Add(this.listBoxResults);
            this.Name = "FormList";
            this.Text = "Entry List";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button buttonJump;
        private System.Windows.Forms.Button buttonBackMain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        public System.Windows.Forms.ListBox listBoxResults;
    }
}