﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace CapstoneUIMockUp
{
    public partial class FormCreatureEntry : Form
    {
        public static FormCreatureEntry cpm;

        public string creatureName;
        public string creatureMythos;
        public string creatureType;
        public string creatureDescription;
        public string creaturePhoto;

        public int HI;
        public string name;
        public int MaxHI = Data.creatures.Count;

        public FormCreatureEntry()
        {
            InitializeComponent();
            cpm = this;
        }


        private void buttonPrevious_Click(object sender, EventArgs e)
        {
            if (HI == 0)
            {
                HI = MaxHI-1;
                FillPage(HI);
                //return;
            }
            else
            {
                HI--;
                FillPage(HI);
            }
        }

        private void buttonNext_Click(object sender, EventArgs e)
        {

            if (HI == MaxHI-1)
            {
                HI = 0;
                FillPage(HI);
                //return;
            }
            else
            {
                HI++;
                FillPage(HI);
            }
        }

        private void buttonToMain_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormStartScreen.instance.Show();
            this.Dispose();
        }

        /*public void FillPage(int HI_)
        {
            //HI_ = HI;
            foreach (Creature creature in Data.creatures)
            {
                if (creature.HI == HI_)
                {
                    creatureName = creature.Name;
                    creatureMythos = creature.Mythology;
                    creatureType = creature.Type;
                    creatureDescription = creature.Description;
                    creaturePhoto = creature.Photo;

                    cpm.labelName.Text = creatureName;
                    cpm.labelMythos.Text = creatureMythos;
                    cpm.labelType.Text = creatureType;
                    cpm.richTextBoxDesc.Text = creatureDescription;
                    break;
                }
            }
        }*/

        public void FillPage(int HI_)
        {
            //HI_ = HI;
            foreach (Creature creature in Data.creatures)
            {
                if (creature.HI == HI_)
                {
                    creatureName = creature.Name;
                    creatureMythos = creature.Mythology;
                    creatureType = creature.Type;
                    creatureDescription = creature.Description;
                    creaturePhoto = creature.Photo;

                    cpm.labelName.Text = creatureName;
                    cpm.labelMythos.Text = creatureMythos;
                    cpm.labelType.Text = creatureType;
                    cpm.richTextBoxDesc.Text = creatureDescription;
                    //Image image = Image.FromFile(creaturePhoto);
                    //cpm.pictureBoxPhoto.Image = image;
                    //cpm.pictureBoxPhoto.ImageLocation = creaturePhoto;
                    //cpm.pictureBoxPhoto.Image = Image.FromFile(@"..\Photos\" + creaturePhoto);
                    cpm.pictureBoxPhoto.ImageLocation = @"..\Photos\" + creaturePhoto;
                    //cpm.pictureBoxPhoto.SizeMode = PictureBoxSizeMode.StretchImage;
                    //cpm.pictureBoxPhoto.Height = cpm.pictureBoxPhoto.Height;
                    //cpm.pictureBoxPhoto.Width = cpm.pictureBoxPhoto.Image.Width;
                    break;
                }
            }
        }

        /*public void FillPageUsingName(string name_)
        {
            //name = name_;
            foreach (Creature creature in Data.creatures)
            {
                if (creature.Name == name_)
                {
                    creatureName = creature.Name;
                    creatureMythos = creature.Mythology;
                    creatureType = creature.Type;
                    creatureDescription = creature.Description;

                    cpm.labelName.Text = creatureName;
                    cpm.labelMythos.Text = creatureMythos;
                    cpm.labelType.Text = creatureType;
                    cpm.richTextBoxDesc.Text = creatureDescription;
                    //break;
                }
            }
        }*/

        public void FillPageUsingName(string name_)
        {
            //name = name_;
            foreach (Creature creature in Data.creatures)
            {
                if (creature.Name == name_)
                {
                    creatureName = creature.Name;
                    creatureMythos = creature.Mythology;
                    creatureType = creature.Type;
                    creatureDescription = creature.Description;
                    creaturePhoto = creature.Photo;

                    cpm.labelName.Text = creatureName;
                    cpm.labelMythos.Text = creatureMythos;
                    cpm.labelType.Text = creatureType;
                    cpm.richTextBoxDesc.Text = creatureDescription;
                    cpm.pictureBoxPhoto.ImageLocation = @"..\Photos\" + creaturePhoto;
                    /*Image image = Image.FromFile(creaturePhoto);
                    cpm.pictureBoxPhoto.Image = image;
                    cpm.pictureBoxPhoto.Height = image.Height;
                    cpm.pictureBoxPhoto.Width = image.Width;*/
                    break;
                }
            }
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        /*
        // Construct an image object from a file in the local directory.
        // ... This file must exist in the solution.
        Image image = Image.FromFile("BeigeMonitor1.png");
        // Set the PictureBox image property to this image.
        // ... Then, adjust its height and width properties.
        pictureBoxPhoto.Image = image;
        pictureBoxPhoto.Height = image.Height;
        pictureBoxPhoto.Width = image.Width;
        */
    }
}
