﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapstoneUIMockUp
{
    public partial class FormSearchCodex : Form
    {
        public FormCreatureEntry cpm = new FormCreatureEntry();
        public static FormSearchCodex sc;
        public FormList fl = new FormList();
        public string input;


        public FormSearchCodex()
        {
            InitializeComponent();
            sc = this;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Dispose();
            FormStartScreen.instance.Show();
        }

        /*public void populateListBox()
        {
            foreach (Creature creature in Data.creatures)
            {
                //FormList.instance.listBoxResults.Items.Add(creature.Name);
                
            }
        }*/

        private void buttonSearch_Click(object sender, EventArgs e)
        {
            input = sc.textBoxName.Text;
            if (sc.radioButtonName.Checked)
            {
                foreach (Creature creature in Data.creatures)
                {
                    if (input == creature.Name)
                    {
                        cpm.HI = creature.HI;
                        cpm.FillPage(cpm.HI);
                        cpm.Show();
                        sc.Dispose();
                    }
                }
            }
            if (sc.radioButtonMythos.Checked)
            {
                Helper.populateCreatureMythosList(textBoxMythos.Text);
                foreach (Creature creature in Data.creatureMythos)
                {
                    fl.listBoxResults.Items.Add(creature.Name);
                }
                fl.Show();
                sc.Dispose();
            }
            if (sc.radioButtonType.Checked)
            {
                Helper.populateCreatureTypeList(textBoxType.Text);
                foreach (Creature creature in Data.creatureTypes)
                {
                    fl.listBoxResults.Items.Add(creature.Name);
                }
                fl.Show();
                sc.Dispose();
            }
        }
    }
}
