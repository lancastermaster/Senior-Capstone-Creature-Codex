﻿namespace CapstoneUIMockUp
{
    partial class FormStartScreen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormStartScreen));
            this.panel1 = new System.Windows.Forms.Panel();
            this.buttonReadCodex = new System.Windows.Forms.Button();
            this.buttonSearchCodex = new System.Windows.Forms.Button();
            this.buttonCreateNewEntry = new System.Windows.Forms.Button();
            this.buttonJumpCodex = new System.Windows.Forms.Button();
            this.buttonResetCreatureCodex = new System.Windows.Forms.Button();
            this.buttonExitCodex = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.panel1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel1.BackgroundImage")));
            this.panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(389, 316);
            this.panel1.TabIndex = 1;
            // 
            // buttonReadCodex
            // 
            this.buttonReadCodex.BackColor = System.Drawing.SystemColors.Control;
            this.buttonReadCodex.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonReadCodex.BackgroundImage")));
            this.buttonReadCodex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonReadCodex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonReadCodex.Location = new System.Drawing.Point(395, 0);
            this.buttonReadCodex.Name = "buttonReadCodex";
            this.buttonReadCodex.Size = new System.Drawing.Size(48, 49);
            this.buttonReadCodex.TabIndex = 2;
            this.buttonReadCodex.UseVisualStyleBackColor = false;
            this.buttonReadCodex.Click += new System.EventHandler(this.buttonReadCodex_Click);
            // 
            // buttonSearchCodex
            // 
            this.buttonSearchCodex.BackColor = System.Drawing.SystemColors.Control;
            this.buttonSearchCodex.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonSearchCodex.BackgroundImage")));
            this.buttonSearchCodex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonSearchCodex.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonSearchCodex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonSearchCodex.Location = new System.Drawing.Point(395, 110);
            this.buttonSearchCodex.Name = "buttonSearchCodex";
            this.buttonSearchCodex.Size = new System.Drawing.Size(48, 44);
            this.buttonSearchCodex.TabIndex = 3;
            this.buttonSearchCodex.UseVisualStyleBackColor = false;
            this.buttonSearchCodex.Click += new System.EventHandler(this.buttonSearchCodex_Click);
            // 
            // buttonCreateNewEntry
            // 
            this.buttonCreateNewEntry.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonCreateNewEntry.BackgroundImage")));
            this.buttonCreateNewEntry.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonCreateNewEntry.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonCreateNewEntry.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonCreateNewEntry.Location = new System.Drawing.Point(395, 160);
            this.buttonCreateNewEntry.Name = "buttonCreateNewEntry";
            this.buttonCreateNewEntry.Size = new System.Drawing.Size(48, 48);
            this.buttonCreateNewEntry.TabIndex = 4;
            this.buttonCreateNewEntry.UseVisualStyleBackColor = true;
            this.buttonCreateNewEntry.Click += new System.EventHandler(this.buttonCreateNewEntry_Click);
            // 
            // buttonJumpCodex
            // 
            this.buttonJumpCodex.BackColor = System.Drawing.SystemColors.Control;
            this.buttonJumpCodex.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonJumpCodex.BackgroundImage")));
            this.buttonJumpCodex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonJumpCodex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonJumpCodex.Location = new System.Drawing.Point(395, 55);
            this.buttonJumpCodex.Name = "buttonJumpCodex";
            this.buttonJumpCodex.Size = new System.Drawing.Size(48, 49);
            this.buttonJumpCodex.TabIndex = 5;
            this.buttonJumpCodex.UseVisualStyleBackColor = false;
            this.buttonJumpCodex.Click += new System.EventHandler(this.buttonJumpCodex_Click_1);
            // 
            // buttonResetCreatureCodex
            // 
            this.buttonResetCreatureCodex.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonResetCreatureCodex.BackgroundImage")));
            this.buttonResetCreatureCodex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonResetCreatureCodex.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonResetCreatureCodex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonResetCreatureCodex.Location = new System.Drawing.Point(395, 214);
            this.buttonResetCreatureCodex.Name = "buttonResetCreatureCodex";
            this.buttonResetCreatureCodex.Size = new System.Drawing.Size(48, 47);
            this.buttonResetCreatureCodex.TabIndex = 6;
            this.buttonResetCreatureCodex.UseVisualStyleBackColor = true;
            this.buttonResetCreatureCodex.Click += new System.EventHandler(this.buttonResetCreatureCodex_Click);
            // 
            // buttonExitCodex
            // 
            this.buttonExitCodex.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("buttonExitCodex.BackgroundImage")));
            this.buttonExitCodex.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.buttonExitCodex.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonExitCodex.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExitCodex.Location = new System.Drawing.Point(395, 267);
            this.buttonExitCodex.Name = "buttonExitCodex";
            this.buttonExitCodex.Size = new System.Drawing.Size(48, 49);
            this.buttonExitCodex.TabIndex = 7;
            this.buttonExitCodex.UseVisualStyleBackColor = true;
            this.buttonExitCodex.Click += new System.EventHandler(this.buttonExitCodex_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(450, 123);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(74, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Search Codex";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(450, 175);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(90, 13);
            this.label2.TabIndex = 9;
            this.label2.Text = "Create New Entry";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(453, 230);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 13);
            this.label3.TabIndex = 10;
            this.label3.Text = "Reset Codex";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(450, 279);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Exit Codex";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(453, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(66, 13);
            this.label5.TabIndex = 12;
            this.label5.Text = "Read Codex";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(453, 72);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 13;
            this.label6.Text = "Jump To Entry";
            // 
            // FormStartScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 317);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.buttonJumpCodex);
            this.Controls.Add(this.buttonExitCodex);
            this.Controls.Add(this.buttonResetCreatureCodex);
            this.Controls.Add(this.buttonCreateNewEntry);
            this.Controls.Add(this.buttonSearchCodex);
            this.Controls.Add(this.buttonReadCodex);
            this.Controls.Add(this.panel1);
            this.Name = "FormStartScreen";
            this.Text = "Creature Codex";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonReadCodex;
        private System.Windows.Forms.Button buttonSearchCodex;
        private System.Windows.Forms.Button buttonCreateNewEntry;
        private System.Windows.Forms.Button buttonJumpCodex;
        private System.Windows.Forms.Button buttonResetCreatureCodex;
        private System.Windows.Forms.Button buttonExitCodex;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
    }
}

