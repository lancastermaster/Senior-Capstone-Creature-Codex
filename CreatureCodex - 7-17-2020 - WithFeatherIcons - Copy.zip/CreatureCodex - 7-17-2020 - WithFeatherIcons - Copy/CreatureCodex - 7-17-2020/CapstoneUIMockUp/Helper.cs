﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace CapstoneUIMockUp
{
    class Helper
    {
        public static string CreatureDatabase = "creaturedatabase.txt";
        public static string backupCreatureDatabase = "backupcreaturedatabase.txt";


        //-------------------For normal functions
        public static void LoadCreatures()
        {
            string[] data = File.ReadAllLines(CreatureDatabase);
            foreach (string line in data)
            {
                Data.AddData(line);
            }
        }

        public static void saveBeasts(List<string> cStrings)
        {
            string[] beastString = new string[cStrings.Count];


            for (int i = 0; i < cStrings.Count; i++)
            {
                beastString[i] = cStrings[i].ToString();

            }
            File.WriteAllLines(CreatureDatabase, beastString);
        }
        
        public static void populateCreatureList()
        {
            foreach (string line in Data.cString)
            {
                Creature newCreature = new Creature();
                string[] parts = line.Split('^');

                newCreature.HI = int.Parse(parts[0]);
                newCreature.Name = parts[1];
                newCreature.Mythology = parts[2];
                newCreature.Type = parts[3];
                newCreature.Description = parts[4];
                newCreature.Photo = parts[5];

                Data.creatures.Add(newCreature);
            }
        }

        //-------------For List Form
        public static void populateCreatureMythosList(string mythos)
        {
            foreach (Creature creature in Data.creatures)
            {
                if (creature.Mythology == mythos)
                {
                    Creature newCreature = new Creature();
                    
                    newCreature.HI = creature.HI;
                    newCreature.Name = creature.Name;
                    newCreature.Mythology = creature.Mythology;
                    newCreature.Type = creature.Type;
                    newCreature.Description = creature.Description;
                    newCreature.Photo = creature.Photo;

                    Data.creatureMythos.Add(newCreature);
                }
            }
        }
        
        public static void populateCreatureTypeList(string type)
        {
            foreach (Creature creature in Data.creatures)
            {
                if (creature.Type == type)
                {
                    Creature newCreature = new Creature();

                    newCreature.HI = creature.HI;
                    newCreature.Name = creature.Name;
                    newCreature.Mythology = creature.Mythology;
                    newCreature.Type = creature.Type;
                    newCreature.Description = creature.Description;
                    newCreature.Photo = creature.Photo;

                    Data.creatureTypes.Add(newCreature);
                }
            }
        }

        

        //-----------------For Reset
       
      
        public static void LoadCreaturesForReset()
        {
            Data.cString.Clear();
            Data.creatures.Clear();
            string[] data = File.ReadAllLines(backupCreatureDatabase);

            foreach (string line in data)
            {
                Data.AddData(line);
            }
        }
    
        public static void saveBeastsforReset(List<string> cStrings)
        {
            string[] beastString = new string[cStrings.Count];
            
            for (int i = 0; i < cStrings.Count; i++)
            {
                beastString[i] = cStrings[i];
            }
            File.WriteAllLines(CreatureDatabase, beastString);
           
        }

        public static void clearFileForReset()
        {
            FileStream fileStream = File.Open(CreatureDatabase, FileMode.Open);
            fileStream.SetLength(0);
            fileStream.Close();
        }

        public static void populateCreatureList(List<Creature> creatureList)
        {
            foreach (string line in Data.cString)
            {
                Creature newCreature = new Creature();
                string[] parts = line.Split('^');

                newCreature.HI = int.Parse(parts[0]);
                newCreature.Name = parts[1];
                newCreature.Mythology = parts[2];
                newCreature.Type = parts[3];
                newCreature.Description = parts[4];
                newCreature.Photo = parts[5];

                Data.creatureList.Add(newCreature);
            }
        }

        public static void resetFile()
        {
            LoadCreaturesForReset();
            clearFileForReset();
            saveBeastsforReset(Data.cString);
        }
    }
}
