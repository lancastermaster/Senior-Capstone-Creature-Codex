﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapstoneUIMockUp
{
    public partial class FormJumpToCreature : Form
    {
        public FormCreatureEntry cpm = new FormCreatureEntry();
        public FormJumpToCreature jtc;
        
        public FormJumpToCreature()
        {
            InitializeComponent();
            jtc = this;
            populateListBox();
            jtc.listBox1.SelectedIndex = 0;
        }

        private void buttonCancel_Click(object sender, EventArgs e)
        {
            this.Hide();
            FormStartScreen.instance.Show();
            this.Dispose();
        }

        public void populateListBox()
        {
            foreach (Creature creature in Data.creatures)
            {
                jtc.listBox1.Items.Add(creature.Name);
            }
        }

        private void buttonJump_Click(object sender, EventArgs e)
        {
            //string selectedItem = listBox1.Items[listBox1.SelectedIndex].ToString();
            //Console.WriteLine("Creature Count = " + Data.creatures.Count);
            foreach (Creature creature in Data.creatures)
            {
               
                if (creature.Name == jtc.listBox1.SelectedItem.ToString())
                
                {
                    cpm.FillPage(creature.HI);
                    cpm.Show();
                    jtc.Dispose();
                }
                else
                {
                  
                }
             } 
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
